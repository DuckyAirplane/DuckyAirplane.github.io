# Deep-Q-Learning-Maze-Agent

## Project Overview

This project is a reinforcement learning maze agent built with a Jupyter Notebook. The goal was to train an intelligent pirate agent to navigate a maze and find treasure using deep Q-learning. This is a demonstration to how neural networks and reinforcement learning can be used to solve a pathfinding problem through rewards, exploration, and repeated training.

## Work Completed

For this project, I was given starter code that included the maze environment, helper classes, experience replay structure, and parts of the neural network setup. The provided code handled the basic game environment and gave the agent a space to learn from.

The main code I created was the deep Q-learning training logic for the pirate agent. I added the logic for choosing actions, storing experiences, training from past moves, updating rewards, tracking win rate, and improving the agent’s ability to reach the goal. This helped turn the starter notebook into a working intelligent agent that could learn from repeated attempts.

## Connection to Computer Science

Computer scientists solve problems by designing, testing, and improving systems that use data and logic. This matters because software is used in almost every field, including business, healthcare, security, education, entertainment, and transportation. Well-built systems can save time, reduce errors, and help people make better decisions.

This project helped me see how computer science is not only about writing code. It is also about understanding a problem, breaking it into smaller pieces, testing solutions, and improving the result over time. With the maze agent, I had to think about how the agent learns, how rewards affect behavior, and how to measure whether the solution was actually working.


## Ethical Responsibilities

Ethical responsibilities include protecting users, being honest about what a system can and cannot do, and making sure the software is reliable. For the end user, this means considering safety, fairness, privacy, and trust. Organization requires writing clear code, documenting important decisions, protecting data, and not hiding problems in the system.

In AI projects, ethics are especially important because an intelligent system can make decisions that affect real people. Developers need to test their systems carefully, avoid misleading results, and make sure the final product is used responsibly.

